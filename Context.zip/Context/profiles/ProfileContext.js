import { createContext } from "react";

const profileContext = createContext();


export default profileContext;

//react m context api ka use krna caahta hu dedo