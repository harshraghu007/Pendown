import { createContext } from "react";

const noteContext = createContext();


export default noteContext;

//react m context api ka use krna caahta hu dedo