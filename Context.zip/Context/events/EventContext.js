import { createContext } from "react";

const eventContext = createContext();


export default eventContext;

//react m context api ka use krna caahta hu dedo