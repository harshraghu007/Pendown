import { createContext } from "react";

const matContext = createContext();


export default matContext;

//react m context api ka use krna caahta hu dedo